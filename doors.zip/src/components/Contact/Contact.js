// import React from 'react';
// import { Container, Row, Col, Form, Button } from 'react-bootstrap';
// import contactBanner from '../../assests/contact-page-banner.jpg';
// import { FaMapMarkerAlt, FaPhoneAlt, FaEnvelope } from 'react-icons/fa';
// import './Contact.css';

// const Contact = () => {
//   return (
//     <div className="contact-page-wrapper">
//       {/* Banner Section */}
//       <div className="contact-banner">
//         <img src={contactBanner} alt="Contact Banner" />
//         <div className="contact-banner-text">Contact Us</div>
//       </div>

//       {/* Content Section */}
//       <Container className="mt-5 pb-5">
//         <Row>
//           {/* Left Column */}
//           <Col md={6} className="mb-4">
//             <h3>Grow Your Furniture Business with Us</h3>
//             <p className='contact-page-info-parms'>
//               We’ll work closely with you to understand your unique needs and goals, and build a better online shopping
//               experience that grows sales online and in your stores.
//             </p>
//             <p className='contact-page-info-parms'>
//               Please fill out the form for more information on how we can support your success in the furniture eCommerce industry.
//             </p>

//             <div className="mt-4">
//               <p className='mb-5'>
//                 <FaMapMarkerAlt className="me-3 contact-page-info-parms" />
//                 <strong className='fs-5'>ADDRESS</strong><br />
//                 <p className='mt-1 ms-5 contact-page-info-parms'>68 Harrison Ave, Ste 605 PMB 13380<br />
//                   Boston, MA 02111</p>
//               </p>
//               <p className='mb-5'>
//                 <FaPhoneAlt className="me-3 contact-page-info-parms" />
//                 <strong className='fs-5'>CALL US</strong><br />
//                 <p className='mt-1 ms-5 contact-page-info-parms'>
//                   (617) 275-7200
//                 </p>

//               </p>
//               <p className='mb-5'>
//                 <FaEnvelope className="me-3 contact-page-info-parms" />
//                 <strong className='fs-5'>EMAIL</strong><br />
//                 <p className='mt-1 ms-5 contact-page-info-parms'>contact@yourcompany.com</p>
//               </p>
//             </div>

//           </Col>


//           {/* Right Column - Contact Form */}
//           <Col md={6} className="p-4 shadow-lg rounded-4 contact-page-input-section">
//             <h4 className="mb-4 text-white fw-semibold">Let Us Know How We Can Help</h4>
//             <Form>
//               <Row className="mb-3">
//                 <Col>
//                   <Form.Floating className="mb-3">
//                     <Form.Control
//                       id="firstName"
//                       type="text"
//                       placeholder="First Name"
//                       required
//                       className="contact-page-input-fields text-white"
//                     />
//                     <label htmlFor="firstName">First Name*</label>
//                   </Form.Floating>
//                 </Col>
//                 <Col>
//                   <Form.Floating className="mb-3">
//                     <Form.Control
//                       id="lastName"
//                       type="text"
//                       placeholder="Last Name"
//                       required
//                       className="contact-page-input-fields text-white"
//                     />
//                     <label htmlFor="lastName">Last Name*</label>
//                   </Form.Floating>
//                 </Col>
//               </Row>

//               <Form.Floating className="mb-3">
//                 <Form.Control
//                   id="email"
//                   type="email"
//                   placeholder="Email"
//                   required
//                   className="contact-page-input-fields text-white"
//                 />
//                 <label htmlFor="email">Email*</label>
//               </Form.Floating>

//               {/* Keep normal style or use Form.Floating if needed */}
//               <Form.Group className="mb-4">
//                 <Form.Label className="fw-semibold">Message</Form.Label>
//                 <Form.Control
//                   as="textarea"
//                   rows={5}

//                   className="contact-page-input-fields text-white"
//                 />
//               </Form.Group>

//               <Button variant="light" size="lg" className="px-4 fw-semibold">
//                 Submit
//               </Button>
//             </Form>
//           </Col>


//         </Row>
//       </Container>
//     </div>
//   );
// };

// export default Contact;
import React, { useState } from 'react';
import { Container, Form, Button, Alert } from 'react-bootstrap';
import contactBanner from '../../assests/contact-page-banner.jpg';
import { FaMapMarkerAlt, FaPhoneAlt, FaEnvelope } from 'react-icons/fa';
import './Contact.css';

const Contact = () => {
  // Form state
  const [form, setForm] = useState({
    firstName: '',
    lastName: '',
    email: '',
    message: '',
    subject: '',
  });
  const [errors, setErrors] = useState({});
  const [showSuccess, setShowSuccess] = useState(false);

  // Handle input changes
  const handleChange = (e) => {
    setForm({ ...form, [e.target.id]: e.target.value });
    setErrors({ ...errors, [e.target.id]: '' });
  };

  // Validate form
  const validate = () => {
    const newErrors = {};
    if (!form.firstName) newErrors.firstName = 'First Name is required';
    if (!form.lastName) newErrors.lastName = 'Last Name is required';
    if (!form.email) newErrors.email = 'Email is required';
    else if (!form.email.includes('@')) newErrors.email = 'Invalid email';
    return newErrors;
  };

  // Handle form submission
  const handleSubmit = (e) => {
    e.preventDefault();
    const newErrors = validate();
    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }
    setErrors({});
    setShowSuccess(true);
    setTimeout(() => {
      setForm({ firstName: '', lastName: '', email: '', message: '', subject: '' });
      setShowSuccess(false);
    }, 2000);
  };

  return (
    <div className="contact-page">
      {/* Banner */}
      <div className="contact-banner">
        <img src={contactBanner} alt="Contact Banner" />
        <div className="contact-banner-text">Contact Us</div>
      </div>

      {/* Contact Info Section with 3 Icons */}
      <div className="contact-info-section">
        <div className="col-md-4 contact-info-item">
          <div className="contact-icon-wrapper">
            <FaMapMarkerAlt />
          </div>
          <span className="contact-info">
            198 West 21th Street, Suite 721, New York NY 10016
          </span>
        </div>
        <div className="contact-info-item">
          <div className="col-md-4 contact-icon-wrapper">
            <FaPhoneAlt />
          </div>
          <a href="tel:+1235235598" className="contact-info text-decoration-none">
            +1235 2355 98
          </a>
        </div>
        <div className=" col-md-4 contact-info-item">
          <div className="contact-icon-wrapper">
            <FaEnvelope />
          </div>
          <a href="mailto:info@yoursite.com" className="contact-info text-decoration-none">
            info@yoursite.com
          </a>
        </div>
      </div>

      {/* Main Content (Form and Image) */}
      <Container className="my-5">
        <div className="contact-content">
          {/* Form Section */}
          <div className="contact-form">
            <h4 className="mb-3">Contact Us</h4>
            {showSuccess && <Alert variant="success">Message sent!</Alert>}
            <Form onSubmit={handleSubmit}>
              <Form.Floating className="mb-3">
                <Form.Control
                  id="firstName"
                  type="text"
                  placeholder="First Name"
                  value={form.firstName}
                  onChange={handleChange}
                  className={`contact-input ${errors.firstName ? 'is-invalid' : ''}`}
                />
                <label htmlFor="firstName">First Name*</label>
                {errors.firstName && (
                  <div className="invalid-feedback">{errors.firstName}</div>
                )}
              </Form.Floating>

              <Form.Floating className="mb-3">
                <Form.Control
                  id="lastName"
                  type="text"
                  placeholder="Last Name"
                  value={form.lastName}
                  onChange={handleChange}
                  className={`contact-input ${errors.lastName ? 'is-invalid' : ''}`}
                />
                <label htmlFor="lastName">Last Name*</label>
                {errors.lastName && (
                  <div className="invalid-feedback">{errors.lastName}</div>
                )}
              </Form.Floating>

              <Form.Floating className="mb-3">
                <Form.Control
                  id="email"
                  type="email"
                  placeholder="Email"
                  value={form.email}
                  onChange={handleChange}
                  className={`contact-input ${errors.email ? 'is-invalid' : ''}`}
                />
                <label htmlFor="email">Email Address*</label>
                {errors.email && <div className="invalid-feedback">{errors.email}</div>}
              </Form.Floating>

              <Form.Floating className="mb-3">
                <Form.Control
                  id="subject"
                  type="text"
                  placeholder="Subject"
                  value={form.subject}
                  onChange={handleChange}
                  className="contact-input"
                />
                <label htmlFor="subject">Subject</label>
              </Form.Floating>

              <Form.Group className="mb-3">
                <Form.Label>Message</Form.Label>
                <Form.Control
                  as="textarea"
                  rows={3}
                  id="message"
                  value={form.message}
                  onChange={handleChange}
                  className="contact-input"
                />
              </Form.Group>

              <Button type="submit" className="btn-submit">
                Send Message
              </Button>
            </Form>
          </div>

          {/* Image Section */}
          <div className="contact-image">
            <img src={contactBanner} alt="Contact Image" />
          </div>
        </div>
      </Container>
    </div>
  );
};

export default Contact;